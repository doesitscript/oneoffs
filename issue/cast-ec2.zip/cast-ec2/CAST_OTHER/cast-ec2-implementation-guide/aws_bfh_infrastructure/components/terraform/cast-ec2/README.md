# CAST EC2 Module

This Terraform module creates a Windows Server 2022 EC2 instance configured for CAST application deployment.

## Features

- **Windows Server 2022**: Pre-configured with necessary Windows features
- **Security**: Configurable security groups with RDP, HTTP, HTTPS, and WinRM access
- **IAM Integration**: IAM role and instance profile with appropriate permissions
- **Monitoring**: CloudWatch integration with custom metrics and alarms
- **Storage**: Configurable root volume and additional EBS volumes
- **Logging**: CloudWatch Logs integration for application and system logs
- **Automation**: PowerShell user data script for initial configuration

## Usage

```hcl
module "cast_ec2" {
  source = "../../components/terraform/cast-ec2"

  # Required variables
  app_name      = "cast"
  environment   = "prod"
  vpc_id        = "vpc-12345678"
  subnet_id     = "subnet-12345678"
  ami_id        = "ami-0abcdef1234567890"
  key_pair_name = "my-key-pair"

  # Optional variables
  instance_type = "r5a.24xlarge"
  s3_bucket_name = "my-cast-bucket"
  
  # Security configuration
  rdp_cidr_blocks = ["10.0.0.0/8"]
  https_cidr_blocks = ["10.0.0.0/8"]
  
  # Storage configuration
  root_volume_size = 200
  additional_volumes = [
    {
      device_name           = "/dev/sdf"
      volume_type           = "gp3"
      volume_size           = 500
      delete_on_termination = false
    }
  ]
  
  # Monitoring configuration
  enable_detailed_monitoring = true
  log_retention_days        = 30
  cpu_threshold            = 80
  disk_threshold           = 20
  
  # Tagging
  tags = {
    Project     = "CAST"
    Owner       = "DevOps Team"
    CostCenter  = "Engineering"
  }
}
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0 |
| aws | >= 5.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 5.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| app_name | Name of the application (e.g., 'cast') | `string` | n/a | yes |
| environment | Environment name (e.g., 'dev', 'staging', 'prod') | `string` | n/a | yes |
| vpc_id | VPC ID where the EC2 instance will be deployed | `string` | n/a | yes |
| subnet_id | Subnet ID where the EC2 instance will be deployed | `string` | n/a | yes |
| ami_id | AMI ID for Windows Server 2022 | `string` | n/a | yes |
| key_pair_name | Name of the EC2 Key Pair for SSH access | `string` | n/a | yes |
| instance_type | EC2 instance type | `string` | `"r5a.24xlarge"` | no |
| s3_bucket_name | S3 bucket name for CAST application data | `string` | `""` | no |
| secrets_manager_arns | List of Secrets Manager ARNs the instance can access | `list(string)` | `[]` | no |
| ssm_parameter_arns | List of SSM Parameter ARNs the instance can access | `list(string)` | `[]` | no |
| rdp_cidr_blocks | CIDR blocks allowed for RDP access | `list(string)` | `["10.0.0.0/8"]` | no |
| https_cidr_blocks | CIDR blocks allowed for HTTPS access | `list(string)` | `["10.0.0.0/8"]` | no |
| http_cidr_blocks | CIDR blocks allowed for HTTP access | `list(string)` | `["10.0.0.0/8"]` | no |
| winrm_cidr_blocks | CIDR blocks allowed for WinRM access | `list(string)` | `["10.0.0.0/8"]` | no |
| root_volume_type | Type of root volume | `string` | `"gp3"` | no |
| root_volume_size | Size of root volume in GB | `number` | `100` | no |
| additional_volumes | Additional EBS volumes to attach | `list(object)` | `[]` | no |
| enable_detailed_monitoring | Enable detailed monitoring for the instance | `bool` | `true` | no |
| log_retention_days | Number of days to retain CloudWatch logs | `number` | `30` | no |
| cpu_threshold | CPU utilization threshold for CloudWatch alarm | `number` | `80` | no |
| disk_threshold | Disk space threshold for CloudWatch alarm (percentage free) | `number` | `20` | no |
| alarm_actions | List of ARNs to notify when alarms trigger | `list(string)` | `[]` | no |
| tags | Additional tags to apply to all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| instance_id | ID of the CAST EC2 instance |
| instance_arn | ARN of the CAST EC2 instance |
| instance_private_ip | Private IP address of the CAST EC2 instance |
| instance_public_ip | Public IP address of the CAST EC2 instance (if applicable) |
| security_group_id | ID of the security group created for the CAST EC2 instance |
| iam_role_arn | ARN of the IAM role created for the CAST EC2 instance |
| cloudwatch_log_group_name | Name of the CloudWatch log group created for the CAST EC2 instance |
| connection_info | Connection information for the CAST EC2 instance |
| resource_summary | Summary of all resources created by this module |

## Security Considerations

- **Network Security**: Security groups are configured with restrictive access rules
- **IAM Permissions**: IAM role follows principle of least privilege
- **Encryption**: All EBS volumes are encrypted
- **Monitoring**: CloudWatch alarms for CPU and disk utilization
- **Logging**: Comprehensive logging to CloudWatch Logs

## Monitoring

The module creates the following CloudWatch alarms:

- **High CPU**: Triggers when CPU utilization exceeds the threshold
- **Low Disk Space**: Triggers when disk space falls below the threshold

## User Data Script

The module includes a PowerShell user data script that:

- Enables necessary Windows features
- Installs AWS CLI v2 and CloudWatch agent
- Configures Windows Firewall
- Sets up WinRM for remote management
- Creates application directories
- Configures log rotation
- Sets up monitoring and logging

## Examples

### Basic Usage

```hcl
module "cast_ec2_basic" {
  source = "../../components/terraform/cast-ec2"

  app_name      = "cast"
  environment   = "dev"
  vpc_id        = var.vpc_id
  subnet_id     = var.subnet_id
  ami_id        = var.windows_server_2022_ami
  key_pair_name = var.key_pair_name
}
```

### Production Configuration

```hcl
module "cast_ec2_prod" {
  source = "../../components/terraform/cast-ec2"

  app_name      = "cast"
  environment   = "prod"
  vpc_id        = var.vpc_id
  subnet_id     = var.subnet_id
  ami_id        = var.windows_server_2022_ami
  key_pair_name = var.key_pair_name
  
  instance_type = "r5a.24xlarge"
  root_volume_size = 200
  
  additional_volumes = [
    {
      device_name           = "/dev/sdf"
      volume_type           = "gp3"
      volume_size           = 1000
      delete_on_termination = false
    }
  ]
  
  s3_bucket_name = "cast-prod-data"
  secrets_manager_arns = [
    "arn:aws:secretsmanager:us-east-2:123456789012:secret:cast/db-credentials"
  ]
  
  alarm_actions = [
    "arn:aws:sns:us-east-2:123456789012:cast-alerts"
  ]
  
  tags = {
    Project     = "CAST"
    Environment = "Production"
    Owner       = "DevOps Team"
    CostCenter  = "Engineering"
  }
}
```

## License

Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0










