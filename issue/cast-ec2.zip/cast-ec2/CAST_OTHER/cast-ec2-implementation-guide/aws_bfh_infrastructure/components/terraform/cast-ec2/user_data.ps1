# PowerShell script for Windows Server 2022 configuration
# This script configures the CAST EC2 instance with necessary software and settings

# Set execution policy
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force

# Enable Windows features
Write-Host "Enabling Windows features..."
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole, IIS-WebServer, IIS-CommonHttpFeatures, IIS-HttpErrors, IIS-HttpLogging, IIS-RequestMonitor, IIS-HttpTracing, IIS-Security, IIS-RequestFiltering, IIS-Performance, IIS-WebServerManagementTools, IIS-ManagementConsole, IIS-IIS6ManagementCompatibility, IIS-Metabase, IIS-ASPNET45 -All

# Install Chocolatey
Write-Host "Installing Chocolatey..."
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Install AWS CLI v2
Write-Host "Installing AWS CLI v2..."
choco install awscli -y

# Install CloudWatch agent
Write-Host "Installing CloudWatch agent..."
$cloudwatchAgentUrl = "https://s3.amazonaws.com/amazoncloudwatch-agent/windows/amd64/latest/amazon-cloudwatch-agent.msi"
$cloudwatchAgentPath = "C:\temp\amazon-cloudwatch-agent.msi"
New-Item -ItemType Directory -Force -Path "C:\temp"
Invoke-WebRequest -Uri $cloudwatchAgentUrl -OutFile $cloudwatchAgentPath
Start-Process msiexec.exe -Wait -ArgumentList '/I C:\temp\amazon-cloudwatch-agent.msi /quiet'

# Install SSM agent (usually pre-installed on Windows Server 2022)
Write-Host "Ensuring SSM agent is running..."
Start-Service AmazonSSMAgent
Set-Service AmazonSSMAgent -StartupType Automatic

# Configure CloudWatch agent
Write-Host "Configuring CloudWatch agent..."
$cloudwatchConfig = @"
{
    "metrics": {
        "namespace": "CWAgent",
        "metrics_collected": {
            "cpu": {
                "measurement": [
                    "cpu_usage_idle",
                    "cpu_usage_iowait",
                    "cpu_usage_user",
                    "cpu_usage_system"
                ],
                "metrics_collection_interval": 60
            },
            "disk": {
                "measurement": [
                    "used_percent"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "diskio": {
                "measurement": [
                    "io_time"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "mem": {
                "measurement": [
                    "mem_used_percent"
                ],
                "metrics_collection_interval": 60
            }
        }
    },
    "logs": {
        "logs_collected": {
            "files": {
                "collect_list": [
                    {
                        "file_path": "C:\\Program Files\\Amazon\\SSM\\Logs\\amazon-ssm-agent.log",
                        "log_group_name": "/aws/ec2/${app_name}-${environment}-cast-ec2/ssm-agent",
                        "log_stream_name": "{instance_id}/ssm-agent.log"
                    },
                    {
                        "file_path": "C:\\ProgramData\\Amazon\\AmazonCloudWatchAgent\\Logs\\amazon-cloudwatch-agent.log",
                        "log_group_name": "/aws/ec2/${app_name}-${environment}-cast-ec2/cloudwatch-agent",
                        "log_stream_name": "{instance_id}/cloudwatch-agent.log"
                    }
                ]
            }
        }
    }
}
"@

$cloudwatchConfigPath = "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent.json"
$cloudwatchConfig | Out-File -FilePath $cloudwatchConfigPath -Encoding UTF8

# Start CloudWatch agent
Write-Host "Starting CloudWatch agent..."
& "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent.exe" -config $cloudwatchConfigPath -s

# Create application directory
Write-Host "Creating application directory..."
New-Item -ItemType Directory -Force -Path "C:\CAST"

# Download and install CAST application (placeholder - replace with actual installation)
Write-Host "Setting up CAST application..."
# Add your CAST application installation logic here

# Configure Windows Firewall
Write-Host "Configuring Windows Firewall..."
New-NetFirewallRule -DisplayName "CAST HTTP" -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow
New-NetFirewallRule -DisplayName "CAST HTTPS" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow
New-NetFirewallRule -DisplayName "CAST RDP" -Direction Inbound -Protocol TCP -LocalPort 3389 -Action Allow

# Configure WinRM
Write-Host "Configuring WinRM..."
winrm quickconfig -q
winrm set winrm/config/service/auth '@{Basic="true"}'
winrm set winrm/config/service '@{AllowUnencrypted="false"}'

# Set up log rotation
Write-Host "Setting up log rotation..."
$logRotationScript = @"
# Log rotation script for CAST application
Get-ChildItem "C:\CAST\Logs" -Recurse -File | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Force
"@

$logRotationScriptPath = "C:\Scripts\log-rotation.ps1"
New-Item -ItemType Directory -Force -Path "C:\Scripts"
$logRotationScript | Out-File -FilePath $logRotationScriptPath -Encoding UTF8

# Create scheduled task for log rotation
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-File $logRotationScriptPath"
$trigger = New-ScheduledTaskTrigger -Daily -At 2AM
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -TaskName "CAST Log Rotation" -Description "Rotates CAST application logs daily"

# Create system information file
Write-Host "Creating system information file..."
$systemInfo = @"
CAST EC2 Instance Information
============================
Instance ID: $env:COMPUTERNAME
Application: ${app_name}
Environment: ${environment}
Region: ${region}
Account ID: ${account_id}
Deployment Date: $(Get-Date)
Windows Version: $((Get-WmiObject -Class Win32_OperatingSystem).Caption)
"@

$systemInfo | Out-File -FilePath "C:\CAST\system-info.txt" -Encoding UTF8

# Final configuration
Write-Host "Finalizing configuration..."
# Add any final configuration steps here

Write-Host "CAST EC2 instance configuration completed successfully!"
Write-Host "Instance is ready for CAST application deployment."

# Signal completion
$completionSignal = @{
    Status = "Success"
    Message = "CAST EC2 instance configuration completed"
    Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    InstanceId = $env:COMPUTERNAME
}

$completionSignal | ConvertTo-Json | Out-File -FilePath "C:\CAST\deployment-status.json" -Encoding UTF8










