# CAST EC2 Deployment Workspace

This workspace deploys a CAST EC2 instance using the cast-ec2 module from the aws_bfh_infrastructure repository.

## Overview

This workspace provides a production-ready deployment configuration for a CAST application running on Windows Server 2022. It follows the organizational patterns established in the aws_bfh_infrastructure repository.

## Prerequisites

Before deploying this workspace, ensure you have:

1. **Terraform Cloud Workspace**: A workspace named `ws-cast-ec2-{environment}` in the `alliancedata` organization
2. **AWS Credentials**: Proper AWS credentials configured in Terraform Cloud
3. **Network Resources**: VPC and subnet IDs where the instance will be deployed
4. **AMI**: Windows Server 2022 AMI ID for the target region
5. **Key Pair**: EC2 key pair for RDP access
6. **S3 Bucket**: S3 bucket for CAST application data (optional)
7. **Secrets**: Secrets Manager secrets and SSM parameters (optional)

## Configuration

### Required Variables

Update the following variables in `cast-ec2.tfvars`:

- `vpc_id`: VPC ID where the instance will be deployed
- `subnet_id`: Subnet ID where the instance will be deployed
- `ami_id`: Windows Server 2022 AMI ID
- `key_pair_name`: EC2 key pair name for RDP access

### Optional Variables

Configure the following variables as needed:

- `s3_bucket_name`: S3 bucket for application data
- `secrets_manager_arns`: List of Secrets Manager ARNs
- `ssm_parameter_arns`: List of SSM Parameter ARNs
- `alarm_actions`: SNS topic ARNs for alerts

## Deployment

### 1. Initialize Terraform

```bash
terraform init
```

### 2. Plan Deployment

```bash
terraform plan -var-file="cast-ec2.tfvars"
```

### 3. Apply Configuration

```bash
terraform apply -var-file="cast-ec2.tfvars"
```

## Post-Deployment

After successful deployment:

1. **RDP Access**: Use the private IP address and your key pair to RDP into the instance
2. **Application Setup**: Install and configure the CAST application
3. **Monitoring**: Verify CloudWatch alarms are working
4. **Logging**: Check CloudWatch Logs for application logs

## Outputs

The deployment provides the following outputs:

- `instance_id`: EC2 instance ID
- `instance_private_ip`: Private IP address
- `connection_info`: Complete connection information
- `resource_summary`: Summary of all created resources

## Security Considerations

- **Network Security**: Security groups restrict access to necessary ports only
- **IAM Permissions**: IAM role follows principle of least privilege
- **Encryption**: All EBS volumes are encrypted
- **Monitoring**: CloudWatch alarms for CPU and disk utilization

## Monitoring

The deployment includes:

- **CloudWatch Alarms**: CPU and disk space monitoring
- **CloudWatch Logs**: Application and system logs
- **Detailed Monitoring**: Enhanced EC2 monitoring

## Troubleshooting

### Common Issues

1. **AMI Not Found**: Ensure the AMI ID is correct for the target region
2. **Subnet Issues**: Verify the subnet is in the correct VPC and AZ
3. **Key Pair Issues**: Ensure the key pair exists in the target region
4. **Security Group Issues**: Check that the security group allows necessary traffic

### Logs

Check the following for troubleshooting:

- **Terraform Logs**: Terraform Cloud workspace logs
- **EC2 Logs**: System logs in CloudWatch Logs
- **Application Logs**: Application-specific logs in CloudWatch Logs

## Maintenance

### Regular Tasks

- **Security Updates**: Apply Windows updates regularly
- **Application Updates**: Update CAST application as needed
- **Log Rotation**: Logs are automatically rotated
- **Backup**: Ensure EBS snapshots are taken regularly

### Scaling

To scale the deployment:

1. **Vertical Scaling**: Change the instance type
2. **Horizontal Scaling**: Deploy additional instances
3. **Storage Scaling**: Add additional EBS volumes

## Cost Optimization

- **Instance Type**: Use appropriate instance type for workload
- **Storage**: Use appropriate EBS volume types
- **Monitoring**: Adjust CloudWatch log retention as needed
- **Scheduling**: Consider scheduled start/stop for non-production environments

## Support

For issues with this deployment:

1. Check Terraform Cloud workspace logs
2. Review CloudWatch Logs for application issues
3. Contact the DevOps team for infrastructure issues
4. Contact the CAST application team for application issues

## License

Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0










