I'll analyze your EC2 deployment folder against Terraform patterns across your organization repositories. Let me start by identifying Terraform repositories and then systematically evaluate them.


[3 tools called]

Let me check for the focus repositories mentioned in the task:


[1 tool called]

Now let me check if these focus repos contain Terraform files:


[2 tools called]

Now let me analyze the focus repositories and the terraform-aws-* modules. I'll start with the most promising ones:


[18 tools called]

Now let me analyze my current EC2 folder:


[8 tools called]

Now let me check a few more key repositories to complete my analysis:


[5 tools called]

Now let me check for CI/linting patterns and documentation:


[4 tools called]

Now let me complete my analysis and scoring. Based on my examination of the repositories, I can now provide the comprehensive analysis requested.


[2 tools called]

# Terraform Pattern Analysis and EC2 Deployment Recommendations

## A) Executive Summary

• **Top 3 repos to emulate**: `aws_bfh_infrastructure` (18/20), `aft-global-customizations` (16/20), `terraform-aws-application-ingress-nlb` (14/20)
• **Recommended destination**: `aws_bfh_infrastructure/workspaces/cast-ec2/` - follows established workspace pattern with proper module structure
• **Alternative**: Create new `terraform-aws-ec2-instance` module repo following the `terraform-aws-application-ingress-*` pattern
• **Current cast-ec2 score**: 8/20 - needs significant improvement in module structure, backend configuration, and CI/linting
• **Key gaps**: No remote state backend, no version constraints, no CI/linting, hardcoded values, poor module structure
• **Migration approach**: Transform into reusable module with proper workspace consumption pattern
• **One-week plan**: Day 1-2: Create module structure, Day 3-4: Add backend/versions, Day 5-6: Add CI/linting, Day 7: Test and document

## B) Repo Ranking Table

| Rank | Repo Name | Path | Score/20 | Key Strengths | Notable Gaps | Good Fit for EC2? |
|------|-----------|------|----------|---------------|--------------|-------------------|
| 1 | aws_bfh_infrastructure | `/aws_bfh_infrastructure/` | 18/20 | Module structure, TFC backend, version pinning, workspace pattern | Limited documentation | **Yes** - Perfect workspace pattern for EC2 |
| 2 | aft-global-customizations | `/aft-global-customizations/terraform/` | 16/20 | Module structure, version pinning, tagging strategy, security patterns | No backend config, limited CI | **Yes** - Good module patterns for EC2 security |
| 3 | terraform-aws-application-ingress-nlb | `/terraform-aws-application-ingress-nlb/` | 14/20 | Clean module interface, locals usage, lifecycle rules | No backend, limited validation | **Yes** - Good template for EC2 module |
| 4 | terraform-aws-application-ingress-target-group | `/terraform-aws-application-ingress-target-group/` | 12/20 | Simple module interface, data sources | No backend, no version constraints | **Maybe** - Too simple for EC2 complexity |
| 5 | sectigo-acm-bootstrap | `/sectigo-acm-bootstrap/` | 10/20 | Multi-provider setup, version constraints | No backend, no module structure | **No** - Single-purpose, not reusable |
| 6 | aft-account-customizations | `/aft-account-customizations/` | 8/20 | AFT integration, some module structure | No backend, limited validation | **No** - AFT-specific, not general EC2 |
| 7 | cast-ec2 (current) | `/oneoffs/issue/cast-ec2/CAST/` | 8/20 | Good variable validation, tagging strategy | No backend, no version constraints, hardcoded values | **N/A** - Current implementation |

## C) Pattern Snippets

### Minimal Reusable EC2 Module Template

**`modules/ec2-instance/variables.tf`**:
```hcl
variable "instance_name" {
  description = "Name of the EC2 instance"
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.medium"
}

variable "vpc_id" {
  description = "VPC ID where instance will be deployed"
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID where instance will be deployed"
  type        = string
}

variable "security_group_ids" {
  description = "List of security group IDs"
  type        = list(string)
  default     = []
}

variable "ami_id" {
  description = "AMI ID for the instance"
  type        = string
}

variable "tags" {
  description = "Additional tags to apply to resources"
  type        = map(string)
  default     = {}
}
```

**`modules/ec2-instance/main.tf`**:
```hcl
resource "aws_instance" "this" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  vpc_security_group_ids = var.security_group_ids
  subnet_id              = var.subnet_id

  root_block_device {
    volume_type = "gp3"
    volume_size = 20
    encrypted   = true
    tags = merge(var.tags, {
      Name = "${var.instance_name}-root"
    })
  }

  tags = merge(var.tags, {
    Name = var.instance_name
  })

  lifecycle {
    create_before_destroy = true
  }
}
```

**`modules/ec2-instance/outputs.tf`**:
```hcl
output "instance_id" {
  description = "ID of the EC2 instance"
  value       = aws_instance.this.id
}

output "instance_arn" {
  description = "ARN of the EC2 instance"
  value       = aws_instance.this.arn
}

output "private_ip" {
  description = "Private IP address of the instance"
  value       = aws_instance.this.private_ip
}
```

### Root Module Example

**`workspaces/cast-ec2/main.tf`**:
```hcl
module "cast_ec2" {
  source = "../../components/terraform/ec2-instance"

  instance_name      = "${local.app}-${local.env}-ec2"
  instance_type      = "r5a.24xlarge"
  vpc_id            = data.aws_vpc.cast_vpc.id
  subnet_id         = data.aws_subnet.cast_subnet.id
  security_group_ids = [aws_security_group.cast_sg.id]
  ami_id            = var.ami_id

  tags = local.common_tags
}
```

## D) My Folder Upgrade Plan

### File-by-File Changes

1. **Create module structure**:
   - Move `ec2-instance.tf` → `modules/ec2-instance/main.tf`
   - Move `security-groups.tf` → `modules/ec2-instance/security-groups.tf`
   - Create `modules/ec2-instance/variables.tf` (extract from current `variables.tf`)
   - Create `modules/ec2-instance/outputs.tf` (extract from current `outputs.tf`)

2. **Add backend configuration**:
   - Create `backend.tf` with TFC configuration following `aws_bfh_infrastructure` pattern

3. **Add version constraints**:
   - Create `versions.tf` with proper provider constraints

4. **Improve locals and tagging**:
   - Update `locals.tf` to follow `aws-infrastructure-networkhub-core` tagging pattern

### Concrete Diffs

**Create `versions.tf`**:
```hcl
terraform {
  required_version = ">= 1.8.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}
```

**Create `backend.tf`**:
```hcl
terraform {
  cloud {
    organization = "alliancedata"
    workspaces {
      project = "pr-cast-ec2"
      name    = "cast-ec2-dev"
    }
  }
}
```

**Update `locals.tf`** (lines 15-23):
```diff
-  common_tags = merge(
-    {
-      Project     = local.app
-      Environment = local.env
-      ManagedBy   = "Terraform"
-      Owner       = "CAST Team"
-    },
-    var.tags
-  )
+  common_tags = merge(
+    {
+      "bfh:support-group" = "bfh.castsoftware"
+      "bfh:environment"   = local.env
+      "bfh:project"       = local.app
+      "ManagedBy"         = "Terraform"
+    },
+    var.tags
+  )
```

## E) Validation Checklist

### Local Commands
```bash
# Format and validate
terraform fmt -recursive
terraform validate

# Initialize with backend
terraform init

# Plan deployment
terraform plan

# Lint (if tflint installed)
tflint --init
tflint
```

### Expected Outcomes
- **terraform fmt**: Should pass with no changes needed
- **terraform validate**: Should pass with "Success! The configuration is valid"
- **terraform init**: Should successfully initialize TFC backend
- **terraform plan**: Should show planned changes without errors
- **tflint**: Should pass with no issues (after adding `.tflint.hcl`)

### Sample GitHub Actions Workflow
```yaml
name: Terraform CI
on: [push, pull_request]
jobs:
  terraform:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: hashicorp/setup-terraform@v2
      - run: terraform fmt -check
      - run: terraform validate
      - run: tflint
```

### Sample `.tflint.hcl`
```hcl
plugin "aws" {
  enabled = true
  version = "0.28.4"
  source  = "github.com/terraform-linters/tflint-ruleset-aws"
}

rule "aws_instance_previous_type" {
  enabled = true
}

rule "aws_instance_previous_generation" {
  enabled = true
}
```


[1 tool called]

## Summary

I've completed a comprehensive analysis of your EC2 deployment folder against Terraform patterns across your organization repositories. The analysis reveals that your current `cast-ec2` implementation scores 8/20 and needs significant improvement to align with organizational standards.

**Key Findings:**
- **Best pattern**: `aws_bfh_infrastructure` (18/20) with excellent module structure, TFC backend, and workspace organization
- **Your current code**: Good variable validation and tagging, but lacks backend configuration, version constraints, and proper module structure
- **Recommended destination**: `aws_bfh_infrastructure/workspaces/cast-ec2/` following the established workspace pattern

**Immediate Actions:**
1. Create proper module structure separating reusable components from workspace configuration
2. Add Terraform Cloud backend configuration
3. Implement version constraints and provider pinning
4. Add CI/linting with tflint and GitHub Actions
5. Follow organizational tagging conventions

The provided templates and upgrade plan give you concrete steps to mature your EC2 deployment into a reusable, organization-standard module that can be consumed across multiple accounts and environments.